package com.centuryLink.service;

import com.centuryLink.bean.City;
import java.util.List;

public interface ICityService {

    public List<City> findAll();
}