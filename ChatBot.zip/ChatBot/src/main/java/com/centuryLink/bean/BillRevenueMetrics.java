package com.centuryLink.bean;




public class BillRevenueMetrics {

	private String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBillingAccountName() {
		return billingAccountName;
	}
	public void setBillingAccountName(String billingAccountName) {
		this.billingAccountName = billingAccountName;
	}
	public String getBillingAccountId() {
		return billingAccountId;
	}
	public void setBillingAccountId(String billingAccountId) {
		this.billingAccountId = billingAccountId;
	}
	public String getBillingSystem() {
		return billingSystem;
	}
	public void setBillingSystem(String billingSystem) {
		this.billingSystem = billingSystem;
	}
	public String getBillingLine1Address() {
		return billingLine1Address;
	}
	public void setBillingLine1Address(String billingLine1Address) {
		this.billingLine1Address = billingLine1Address;
	}
	public String getBillingLine2Address() {
		return billingLine2Address;
	}
	public void setBillingLine2Address(String billingLine2Address) {
		this.billingLine2Address = billingLine2Address;
	}
	public String getBillingCityName() {
		return billingCityName;
	}
	public void setBillingCityName(String billingCityName) {
		this.billingCityName = billingCityName;
	}
	public String getBillingStateCode() {
		return billingStateCode;
	}
	public void setBillingStateCode(String billingStateCode) {
		this.billingStateCode = billingStateCode;
	}
	public String getBillingPostalCode() {
		return billingPostalCode;
	}
	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}
	public String getBillingCountryName() {
		return billingCountryName;
	}
	public void setBillingCountryName(String billingCountryName) {
		this.billingCountryName = billingCountryName;
	}
	public String getOwnersRegion() {
		return ownersRegion;
	}
	public void setOwnersRegion(String ownersRegion) {
		this.ownersRegion = ownersRegion;
	}
	public String getSalesRepCuid() {
		return salesRepCuid;
	}
	public void setSalesRepCuid(String salesRepCuid) {
		this.salesRepCuid = salesRepCuid;
	}
	public String getRepQBL() {
		return repQBL;
	}
	public void setRepQBL(String repQBL) {
		this.repQBL = repQBL;
	}
	public String getSalesRepId() {
		return salesRepId;
	}
	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}
	public String getRepName() {
		return repName;
	}
	public void setRepName(String repName) {
		this.repName = repName;
	}
	public String getRevenueMonth() {
		return revenueMonth;
	}
	public void setRevenueMonth(String revenueMonth) {
		this.revenueMonth = revenueMonth;
	}
	public String getSalesRepName() {
		return salesRepName;
	}
	public void setSalesRepName(String salesRepName) {
		this.salesRepName = salesRepName;
	}
	public String getPrevYearToDateMrc() {
		return prevYearToDateMrc;
	}
	public void setPrevYearToDateMrc(String prevYearToDateMrc) {
		this.prevYearToDateMrc = prevYearToDateMrc;
	}
	public String getThreeMonthAvgMrc() {
		return threeMonthAvgMrc;
	}
	public void setThreeMonthAvgMrc(String threeMonthAvgMrc) {
		this.threeMonthAvgMrc = threeMonthAvgMrc;
	}
	public String getCurrentMrc() {
		return currentMrc;
	}
	public void setCurrentMrc(String currentMrc) {
		this.currentMrc = currentMrc;
	}
	public String getYearToDateMrc() {
		return yearToDateMrc;
	}
	public void setYearToDateMrc(String yearToDateMrc) {
		this.yearToDateMrc = yearToDateMrc;
	}
	public String getYearToDateNrc() {
		return yearToDateNrc;
	}
	public void setYearToDateNrc(String yearToDateNrc) {
		this.yearToDateNrc = yearToDateNrc;
	}
	private String billingAccountName;
	private String billingAccountId;
	private String billingSystem;	
	private String billingLine1Address;
	private String billingLine2Address;
	private String billingCityName;
	private String billingStateCode;
	private String billingPostalCode;
	private String billingCountryName;	
	private String ownersRegion;
	private String salesRepCuid;
	private String repQBL;
	private String salesRepId;
	private String repName;
	private String revenueMonth;
	private String salesRepName;
	private String prevYearToDateMrc;
	private String threeMonthAvgMrc;
	private String currentMrc;
	private String yearToDateMrc;
	private String yearToDateNrc;

}