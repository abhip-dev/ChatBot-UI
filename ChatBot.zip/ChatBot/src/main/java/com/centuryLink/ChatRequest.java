package com.centuryLink;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ChatRequest {
	@JsonProperty("question")
	private String question;

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}
}