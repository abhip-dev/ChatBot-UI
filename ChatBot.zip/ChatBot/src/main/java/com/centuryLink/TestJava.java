package com.centuryLink;

public class TestJava {
	public static void main(String[] args) {

		String ret = System.getProperty("java.vendor");
		ret += " " + System.getProperty("java.version");
		ret += "  on " + System.getProperty("os.name");
		ret += " " + System.getProperty("os.version");

		System.out.println(" output is -- > " + ret);
	}
}